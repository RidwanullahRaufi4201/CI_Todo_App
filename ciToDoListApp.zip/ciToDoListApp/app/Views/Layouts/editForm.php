

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo App</title>
</head>
<body>
    
   <div class="container-fluid m-0 p-0 ">
   <ul class="nav p-2 bg-primary">
  <li class="nav-item">
    <a class="nav-link text-white fw-bold" aria-current="page" href="<?php echo site_url()?>">Home</a>
  </li>

</ul>


 
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 m-2">
              <div class="text-center">
                <h4>Edit Todo</h4>
              </div>
              <?php if (session()->getFlashdata('update')) : ?>
                <div class="alert alert-success m-1">
                    <b><?php echo session()->getFlashdata('update') ?></b>
                </div>
            <?php endif ?>
        
                <form action="<?php echo base_url('update-todo')?>"  class="border border-1 p-2 m-md-4" method="post">
                       <div class="form-group m-2">
                           <label for="" class="m-1">Title</label>
                           <input type="text" value="<?php echo $todo['title'] ?>" name="title" class="form-control">
                          
                       </div>
                       <div class="form-group d-none m-2">
                           <label for="" class="m-1">Title</label>
                           <input type="text" value="<?php echo $todo['id'] ?>" name="id" class="form-control">
                          
                       </div>
                       <div class="form-group m-2">
                           <label for="" class="m-1">Description</label>
                           <input type="text" value="<?php echo $todo['description'] ?>" name="description" class="form-control">
                           
                       </div>
                       <div class="form-group m-2 text-center">
                           
                           <input type="submit" value="Add Todo" name="submit" class="btn btn-sm btn-primary">
                       </div>
                </form>
        </div>   
   </div>
</div>

</div>
</body>
</html>