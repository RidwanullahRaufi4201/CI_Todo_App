<?php $this->extend('Layouts/Header')?>

<?php $this->section('content')?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
        <?php if (session()->getFlashdata('success')) : ?>
                <div class="alert alert-success m-1">
                    <b><?php echo session()->getFlashdata('success') ?></b>
                </div>
            <?php endif ?>
            <?php if (session()->getFlashdata('error')) : ?>
                <div class="alert alert-danger m-1">
                    <b><?php echo session()->getFlashdata('error') ?></b>
                </div>
            <?php endif ?>
        
                <form action="<?php echo base_url('save-todo')?>"  class="border border-1 p-2 m-md-4" method="post">
                       <div class="form-group m-2">
                           <label for="" class="m-1">Title</label>
                           <input type="text" name="title" class="form-control">
                          
                       </div>
                       <div class="form-group m-2">
                           <label for="" class="m-1">Description</label>
                          <textarea name="description" class="form-control"></textarea>
                           
                       </div>
                       <div class="form-group m-2 text-center">
                           
                           <input type="submit" value="Add Todo" name="submit" class="btn btn-sm btn-primary">
                       </div>
                </form>
        </div>   
   </div>
</div>

<?php $this->endSection()?>