<?php $this->extend('Layouts/Header')?>

<?php $this->section('content')?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 text-center mt-md-5">
               <a href="" class="text-dark text-center fs-3">Todos</a>
        </div>
    </div>
</div>
<?php $this->endSection()?>