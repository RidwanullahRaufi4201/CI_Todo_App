<?php $this->extend('Layouts/Header')?>

<?php $this->section('content')?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 text-center  m-md-5">
               <a href="" class="text-primary text-center fs-2 ">Todos</a>
        </div>
        <div class="col-md-12">
        <?php if (session()->getFlashdata('success')) : ?>
                <div class="alert alert-success m-1">
                    <b><?php echo session()->getFlashdata('success') ?></b>
                </div>
            <?php endif ?>
        <table class="table table-striped">

            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Published at</th>
                <th>Action</th>
            </tr>   
        <?php
        foreach($allTodos as $todo)
        {?>
           <tr>
               <td><?php echo $todo['title'] ?></td>
               <td><?php echo $todo['description'] ?></td>
               <td><?php echo $todo['published at'] ?></td>
               <td> 
                <a href="delete-todo/<?php echo $todo['id']?>" class="btn btn-sm btn-danger"><i class="fa-solid fa-trash"></i></a>
                <a href="edit-todo/<?php echo $todo['id']?>" class="btn btn-sm btn-success"><i class="fa-solid fa-pen-to-square"></i></a>
              </td>
           </tr>
       <?php  }?>
       
        </table>

        </div>
   
        
    </div>
</div>
<?php $this->endSection()?>