<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\Todos;


class TodosController extends BaseController
{
    protected $helpers = ['form'];
    public function index()
    {
       return view('Layouts/index');
    }

    public function addTodo()
    {
        return view('Layouts/AddTodo');
    }

    public function saveTodo()
    {
        
        $todo=[
            'title'=>$this->request->getPost('title'),
            'description'=>$this->request->getPost('description')
        ];

        $validatioRules=[
            'title'=>'required',
            'description'=>'required',
        ];
        
        if(!$this->validate($validatioRules))
        {
            return redirect()->back()->with('error','Please Fill All Fields');

        }
        $todos=new Todos();
        $todos->insert($todo);
        return redirect()->back()->with('success','Todo Added Successfully');


    }

    public function getAllTodos()
    {
        $todos=new Todos();
      
        return view('Layouts/Todos',['allTodos'=>$todos->findAll()]);
    }

    public function deleteTodo($id)
    {
        $todos=new Todos();
        $todos->delete($id);
        return redirect()->back()->with('success','Todo Deleted Successfully !');
    }

    public function editTodo($id)
    {
        $todos=new Todos();
        return view('Layouts/editForm',['todo'=>$todos->find($id)]);
    }


    public function updateTodo()
    {
        $todos=new Todos();
        $id=$this->request->getPost('id');

        $todo=[
            'title'=>$this->request->getPost('title'),
            'description'=>$this->request->getPost('description')
        ];

        $todos->update($id,$todo);
        return redirect()->back()->with('update','Todo Updated Successfully !');

    }
}
